-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 02, 2014 at 04:02 PM
-- Server version: 5.5.37-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `botangle`
--

-- --------------------------------------------------------

--
-- Table structure for table `acos`
--

CREATE TABLE IF NOT EXISTS `acos` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `foreign_key` int(10) DEFAULT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=221 ;

--
-- Dumping data for table `acos`
--

INSERT INTO `acos` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES
(1, NULL, '', NULL, 'controllers', 1, 444),
(2, 1, '', NULL, 'Acl', 2, 25),
(3, 2, '', NULL, 'AclActions', 3, 16),
(4, 3, '', NULL, 'admin_index', 4, 5),
(5, 3, '', NULL, 'admin_add', 6, 7),
(6, 3, '', NULL, 'admin_edit', 8, 9),
(7, 3, '', NULL, 'admin_delete', 10, 11),
(8, 3, '', NULL, 'admin_move', 12, 13),
(9, 3, '', NULL, 'admin_generate', 14, 15),
(10, 2, '', NULL, 'AclPermissions', 17, 24),
(11, 10, '', NULL, 'admin_index', 18, 19),
(12, 10, '', NULL, 'admin_toggle', 20, 21),
(13, 10, '', NULL, 'admin_upgrade', 22, 23),
(14, 1, '', NULL, 'Blocks', 26, 55),
(15, 14, '', NULL, 'Blocks', 27, 44),
(16, 15, '', NULL, 'admin_toggle', 28, 29),
(17, 15, '', NULL, 'admin_index', 30, 31),
(18, 15, '', NULL, 'admin_add', 32, 33),
(19, 15, '', NULL, 'admin_edit', 34, 35),
(20, 15, '', NULL, 'admin_delete', 36, 37),
(21, 15, '', NULL, 'admin_moveup', 38, 39),
(22, 15, '', NULL, 'admin_movedown', 40, 41),
(23, 15, '', NULL, 'admin_process', 42, 43),
(24, 14, '', NULL, 'Regions', 45, 54),
(25, 24, '', NULL, 'admin_index', 46, 47),
(26, 24, '', NULL, 'admin_add', 48, 49),
(27, 24, '', NULL, 'admin_edit', 50, 51),
(28, 24, '', NULL, 'admin_delete', 52, 53),
(29, 1, '', NULL, 'Comments', 56, 73),
(30, 29, '', NULL, 'Comments', 57, 72),
(31, 30, '', NULL, 'admin_index', 58, 59),
(32, 30, '', NULL, 'admin_edit', 60, 61),
(33, 30, '', NULL, 'admin_delete', 62, 63),
(34, 30, '', NULL, 'admin_process', 64, 65),
(35, 30, '', NULL, 'index', 66, 67),
(36, 30, '', NULL, 'add', 68, 69),
(37, 30, '', NULL, 'delete', 70, 71),
(38, 1, '', NULL, 'Contacts', 74, 97),
(39, 38, '', NULL, 'Contacts', 75, 86),
(40, 39, '', NULL, 'admin_index', 76, 77),
(41, 39, '', NULL, 'admin_add', 78, 79),
(42, 39, '', NULL, 'admin_edit', 80, 81),
(43, 39, '', NULL, 'admin_delete', 82, 83),
(44, 39, '', NULL, 'view', 84, 85),
(45, 38, '', NULL, 'Messages', 87, 96),
(46, 45, '', NULL, 'admin_index', 88, 89),
(47, 45, '', NULL, 'admin_edit', 90, 91),
(48, 45, '', NULL, 'admin_delete', 92, 93),
(49, 45, '', NULL, 'admin_process', 94, 95),
(50, 1, '', NULL, 'Croogo', 98, 99),
(51, 1, '', NULL, 'Extensions', 100, 139),
(52, 51, '', NULL, 'ExtensionsLocales', 101, 112),
(53, 52, '', NULL, 'admin_index', 102, 103),
(54, 52, '', NULL, 'admin_activate', 104, 105),
(55, 52, '', NULL, 'admin_add', 106, 107),
(56, 52, '', NULL, 'admin_edit', 108, 109),
(57, 52, '', NULL, 'admin_delete', 110, 111),
(58, 51, '', NULL, 'ExtensionsPlugins', 113, 124),
(59, 58, '', NULL, 'admin_index', 114, 115),
(60, 58, '', NULL, 'admin_add', 116, 117),
(61, 58, '', NULL, 'admin_delete', 118, 119),
(62, 58, '', NULL, 'admin_toggle', 120, 121),
(63, 58, '', NULL, 'admin_migrate', 122, 123),
(64, 51, '', NULL, 'ExtensionsThemes', 125, 138),
(65, 64, '', NULL, 'admin_index', 126, 127),
(66, 64, '', NULL, 'admin_activate', 128, 129),
(67, 64, '', NULL, 'admin_add', 130, 131),
(68, 64, '', NULL, 'admin_editor', 132, 133),
(69, 64, '', NULL, 'admin_save', 134, 135),
(70, 64, '', NULL, 'admin_delete', 136, 137),
(71, 1, '', NULL, 'FileManager', 140, 175),
(72, 71, '', NULL, 'Attachments', 141, 152),
(73, 72, '', NULL, 'admin_index', 142, 143),
(74, 72, '', NULL, 'admin_add', 144, 145),
(75, 72, '', NULL, 'admin_edit', 146, 147),
(76, 72, '', NULL, 'admin_delete', 148, 149),
(77, 72, '', NULL, 'admin_browse', 150, 151),
(78, 71, '', NULL, 'FileManager', 153, 174),
(79, 78, '', NULL, 'admin_index', 154, 155),
(80, 78, '', NULL, 'admin_browse', 156, 157),
(81, 78, '', NULL, 'admin_editfile', 158, 159),
(82, 78, '', NULL, 'admin_upload', 160, 161),
(83, 78, '', NULL, 'admin_delete_file', 162, 163),
(84, 78, '', NULL, 'admin_delete_directory', 164, 165),
(85, 78, '', NULL, 'admin_rename', 166, 167),
(86, 78, '', NULL, 'admin_create_directory', 168, 169),
(87, 78, '', NULL, 'admin_create_file', 170, 171),
(88, 78, '', NULL, 'admin_chmod', 172, 173),
(89, 1, '', NULL, 'Install', 176, 189),
(90, 89, '', NULL, 'Install', 177, 188),
(91, 90, '', NULL, 'index', 178, 179),
(92, 90, '', NULL, 'database', 180, 181),
(93, 90, '', NULL, 'data', 182, 183),
(94, 90, '', NULL, 'adminuser', 184, 185),
(95, 90, '', NULL, 'finish', 186, 187),
(96, 1, '', NULL, 'Menus', 190, 219),
(97, 96, '', NULL, 'Links', 191, 208),
(98, 97, '', NULL, 'admin_toggle', 192, 193),
(99, 97, '', NULL, 'admin_index', 194, 195),
(100, 97, '', NULL, 'admin_add', 196, 197),
(101, 97, '', NULL, 'admin_edit', 198, 199),
(102, 97, '', NULL, 'admin_delete', 200, 201),
(103, 97, '', NULL, 'admin_moveup', 202, 203),
(104, 97, '', NULL, 'admin_movedown', 204, 205),
(105, 97, '', NULL, 'admin_process', 206, 207),
(106, 96, '', NULL, 'Menus', 209, 218),
(107, 106, '', NULL, 'admin_index', 210, 211),
(108, 106, '', NULL, 'admin_add', 212, 213),
(109, 106, '', NULL, 'admin_edit', 214, 215),
(110, 106, '', NULL, 'admin_delete', 216, 217),
(111, 1, '', NULL, 'Meta', 220, 221),
(112, 1, '', NULL, 'Migrations', 222, 223),
(113, 1, '', NULL, 'Nodes', 224, 259),
(114, 113, '', NULL, 'Nodes', 225, 258),
(115, 114, '', NULL, 'admin_toggle', 226, 227),
(116, 114, '', NULL, 'admin_index', 228, 229),
(117, 114, '', NULL, 'admin_create', 230, 231),
(118, 114, '', NULL, 'admin_add', 232, 233),
(119, 114, '', NULL, 'admin_edit', 234, 235),
(120, 114, '', NULL, 'admin_update_paths', 236, 237),
(121, 114, '', NULL, 'admin_delete', 238, 239),
(122, 114, '', NULL, 'admin_delete_meta', 240, 241),
(123, 114, '', NULL, 'admin_add_meta', 242, 243),
(124, 114, '', NULL, 'admin_process', 244, 245),
(125, 114, '', NULL, 'index', 246, 247),
(126, 114, '', NULL, 'term', 248, 249),
(127, 114, '', NULL, 'promoted', 250, 251),
(128, 114, '', NULL, 'search', 252, 253),
(129, 114, '', NULL, 'view', 254, 255),
(130, 1, '', NULL, 'Search', 260, 261),
(131, 1, '', NULL, 'Settings', 262, 299),
(132, 131, '', NULL, 'Languages', 263, 278),
(133, 132, '', NULL, 'admin_index', 264, 265),
(134, 132, '', NULL, 'admin_add', 266, 267),
(135, 132, '', NULL, 'admin_edit', 268, 269),
(136, 132, '', NULL, 'admin_delete', 270, 271),
(137, 132, '', NULL, 'admin_moveup', 272, 273),
(138, 132, '', NULL, 'admin_movedown', 274, 275),
(139, 132, '', NULL, 'admin_select', 276, 277),
(140, 131, '', NULL, 'Settings', 279, 298),
(141, 140, '', NULL, 'admin_dashboard', 280, 281),
(142, 140, '', NULL, 'admin_index', 282, 283),
(143, 140, '', NULL, 'admin_view', 284, 285),
(144, 140, '', NULL, 'admin_add', 286, 287),
(145, 140, '', NULL, 'admin_edit', 288, 289),
(146, 140, '', NULL, 'admin_delete', 290, 291),
(147, 140, '', NULL, 'admin_prefix', 292, 293),
(148, 140, '', NULL, 'admin_moveup', 294, 295),
(149, 140, '', NULL, 'admin_movedown', 296, 297),
(150, 1, '', NULL, 'Taxonomy', 300, 339),
(151, 150, '', NULL, 'Terms', 301, 314),
(152, 151, '', NULL, 'admin_index', 302, 303),
(153, 151, '', NULL, 'admin_add', 304, 305),
(154, 151, '', NULL, 'admin_edit', 306, 307),
(155, 151, '', NULL, 'admin_delete', 308, 309),
(156, 151, '', NULL, 'admin_moveup', 310, 311),
(157, 151, '', NULL, 'admin_movedown', 312, 313),
(158, 150, '', NULL, 'Types', 315, 324),
(159, 158, '', NULL, 'admin_index', 316, 317),
(160, 158, '', NULL, 'admin_add', 318, 319),
(161, 158, '', NULL, 'admin_edit', 320, 321),
(162, 158, '', NULL, 'admin_delete', 322, 323),
(163, 150, '', NULL, 'Vocabularies', 325, 338),
(164, 163, '', NULL, 'admin_index', 326, 327),
(165, 163, '', NULL, 'admin_add', 328, 329),
(166, 163, '', NULL, 'admin_edit', 330, 331),
(167, 163, '', NULL, 'admin_delete', 332, 333),
(168, 163, '', NULL, 'admin_moveup', 334, 335),
(169, 163, '', NULL, 'admin_movedown', 336, 337),
(170, 1, '', NULL, 'Ckeditor', 340, 341),
(171, 1, '', NULL, 'Users', 342, 439),
(172, 171, '', NULL, 'Roles', 343, 352),
(173, 172, '', NULL, 'admin_index', 344, 345),
(174, 172, '', NULL, 'admin_add', 346, 347),
(175, 172, '', NULL, 'admin_edit', 348, 349),
(176, 172, '', NULL, 'admin_delete', 350, 351),
(177, 171, '', NULL, 'Users', 353, 424),
(178, 177, '', NULL, 'admin_index', 354, 355),
(179, 177, '', NULL, 'admin_add', 356, 357),
(180, 177, '', NULL, 'admin_edit', 358, 359),
(181, 177, '', NULL, 'admin_reset_password', 360, 361),
(182, 177, '', NULL, 'admin_delete', 362, 363),
(183, 177, '', NULL, 'admin_login', 364, 365),
(184, 177, '', NULL, 'admin_logout', 366, 367),
(185, 177, '', NULL, 'index', 368, 369),
(186, 177, '', NULL, 'add', 370, 371),
(187, 177, '', NULL, 'activate', 372, 373),
(188, 177, '', NULL, 'edit', 374, 375),
(189, 177, '', NULL, 'forgot', 376, 377),
(190, 177, '', NULL, 'reset', 378, 379),
(191, 177, '', NULL, 'login', 380, 381),
(192, 177, '', NULL, 'logout', 382, 383),
(193, 177, '', NULL, 'view', 384, 385),
(195, 177, NULL, NULL, 'accountsetting', 386, 387),
(196, 177, NULL, NULL, 'registration', 388, 389),
(197, 177, NULL, NULL, 'billing', 390, 391),
(198, 177, NULL, NULL, 'search', 392, 393),
(199, 177, NULL, NULL, 'lessons', 394, 395),
(202, 171, NULL, NULL, 'Usermessage', 431, 434),
(203, 202, NULL, NULL, 'index', 432, 433),
(204, 177, NULL, NULL, 'lessons_add', 400, 401),
(205, 177, NULL, NULL, 'whiteboarddata', 402, 403),
(206, 177, NULL, NULL, 'changelesson', 404, 405),
(207, 177, NULL, NULL, 'searchstudent', 406, 407),
(208, 177, NULL, NULL, 'lessonreviews', 408, 409),
(209, 177, NULL, NULL, 'confirmedbytutor', 410, 411),
(210, 177, NULL, NULL, 'mycalander', 412, 413),
(211, 177, NULL, NULL, 'calandarevents', 414, 415),
(212, 177, NULL, NULL, 'topchart', 416, 417),
(213, 114, NULL, NULL, 'reportbug', 256, 257),
(214, 1, NULL, NULL, 'Subject', 440, 443),
(215, 214, NULL, NULL, 'search', 441, 442),
(216, 177, NULL, NULL, 'calandareventsprofile', 418, 419),
(217, 171, NULL, NULL, 'Invite', 435, 438),
(218, 217, NULL, NULL, 'index', 436, 437),
(219, 177, NULL, NULL, 'joinuser', 420, 421),
(220, 177, NULL, NULL, 'paymentnotmade', 422, 423);

-- --------------------------------------------------------

--
-- Table structure for table `aros`
--

CREATE TABLE IF NOT EXISTS `aros` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `foreign_key` int(10) DEFAULT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=20 ;

--
-- Dumping data for table `aros`
--

INSERT INTO `aros` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES
(1, 2, 'Role', 1, 'Role-admin', 3, 6),
(2, 3, 'Role', 2, 'Role-tutor', 2, 17),
(3, NULL, 'Role', 3, 'Role-student', 1, 18),
(4, 1, 'User', 1, 'admin', 4, 5),
(10, 2, 'User', 7, 'deepak3', 7, 8),
(15, NULL, 'Role', 4, 'Role-t', 19, 20),
(16, 2, 'User', 2, 'BookNTech', 9, 10),
(17, 2, 'User', 3, 'bonjourhello', 11, 12),
(18, 2, 'User', 4, 'erikejf', 13, 14),
(19, 2, 'User', 5, 'Slichenmyer', 15, 16);

-- --------------------------------------------------------

--
-- Table structure for table `aros_acos`
--

CREATE TABLE IF NOT EXISTS `aros_acos` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `aro_id` int(10) NOT NULL,
  `aco_id` int(10) NOT NULL,
  `_create` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `_read` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `_update` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `_delete` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=101 ;

--
-- Dumping data for table `aros_acos`
--

INSERT INTO `aros_acos` (`id`, `aro_id`, `aco_id`, `_create`, `_read`, `_update`, `_delete`) VALUES
(1, 3, 35, '1', '1', '1', '1'),
(2, 3, 36, '1', '1', '1', '1'),
(3, 2, 37, '1', '1', '1', '1'),
(4, 3, 44, '1', '1', '1', '1'),
(5, 3, 125, '1', '1', '1', '1'),
(6, 3, 126, '1', '1', '1', '1'),
(7, 3, 127, '1', '1', '1', '1'),
(8, 3, 128, '1', '1', '1', '1'),
(9, 3, 129, '1', '1', '1', '1'),
(10, 2, 185, '1', '1', '1', '1'),
(11, 3, 186, '1', '1', '1', '1'),
(12, 3, 187, '1', '1', '1', '1'),
(13, 2, 188, '1', '1', '1', '1'),
(14, 3, 189, '1', '1', '1', '1'),
(15, 3, 190, '1', '1', '1', '1'),
(16, 3, 191, '1', '1', '1', '1'),
(17, 2, 192, '1', '1', '1', '1'),
(18, 2, 193, '1', '1', '1', '1'),
(19, 3, 183, '1', '1', '1', '1'),
(20, 3, 185, '-1', '-1', '-1', '-1'),
(25, 3, 193, '1', '1', '1', '1'),
(26, 3, 192, '-1', '-1', '-1', '-1'),
(27, 2, 173, '-1', '-1', '-1', '-1'),
(28, 2, 174, '-1', '-1', '-1', '-1'),
(29, 2, 175, '-1', '-1', '-1', '-1'),
(30, 2, 176, '-1', '-1', '-1', '-1'),
(31, 3, 176, '-1', '-1', '-1', '-1'),
(32, 3, 175, '-1', '-1', '-1', '-1'),
(33, 3, 174, '-1', '-1', '-1', '-1'),
(34, 3, 173, '-1', '-1', '-1', '-1'),
(35, 3, 188, '1', '1', '1', '1'),
(36, 2, 196, '1', '1', '1', '1'),
(37, 2, 195, '1', '1', '1', '1'),
(38, 3, 195, '-1', '-1', '-1', '-1'),
(39, 3, 196, '1', '1', '1', '1'),
(40, 2, 197, '1', '1', '1', '1'),
(41, 3, 197, '-1', '-1', '-1', '-1'),
(42, 15, 197, '1', '1', '1', '1'),
(43, 15, 196, '1', '1', '1', '1'),
(44, 15, 195, '1', '1', '1', '1'),
(45, 15, 193, '1', '1', '1', '1'),
(46, 2, 198, '1', '1', '1', '1'),
(47, 15, 198, '1', '1', '1', '1'),
(48, 3, 198, '1', '1', '1', '1'),
(49, 2, 199, '1', '1', '1', '1'),
(50, 15, 199, '1', '1', '1', '1'),
(51, 2, 200, '1', '1', '1', '1'),
(52, 3, 200, '1', '1', '1', '1'),
(53, 15, 200, '1', '1', '1', '1'),
(54, 3, 201, '-1', '-1', '-1', '-1'),
(55, 15, 192, '1', '1', '1', '1'),
(56, 15, 191, '1', '1', '1', '1'),
(57, 15, 185, '1', '1', '1', '1'),
(58, 2, 202, '1', '1', '1', '1'),
(59, 3, 202, '-1', '-1', '-1', '-1'),
(60, 15, 202, '1', '1', '1', '1'),
(61, 2, 204, '1', '1', '1', '1'),
(62, 2, 205, '1', '1', '1', '1'),
(63, 15, 205, '1', '1', '1', '1'),
(64, 2, 206, '1', '1', '1', '1'),
(65, 15, 206, '1', '1', '1', '1'),
(66, 2, 207, '1', '1', '1', '1'),
(67, 15, 207, '1', '1', '1', '1'),
(68, 15, 208, '1', '1', '1', '1'),
(69, 2, 209, '1', '1', '1', '1'),
(70, 15, 209, '1', '1', '1', '1'),
(71, 2, 210, '1', '1', '1', '1'),
(72, 2, 211, '1', '1', '1', '1'),
(73, 3, 212, '1', '1', '1', '1'),
(74, 2, 212, '1', '1', '1', '1'),
(75, 15, 212, '1', '1', '1', '1'),
(76, 15, 129, '1', '1', '1', '1'),
(77, 15, 128, '1', '1', '1', '1'),
(78, 15, 125, '1', '1', '1', '1'),
(79, 15, 126, '1', '1', '1', '1'),
(80, 15, 127, '1', '1', '1', '1'),
(81, 2, 213, '1', '1', '1', '1'),
(82, 3, 213, '1', '1', '1', '1'),
(83, 15, 213, '1', '1', '1', '1'),
(84, 2, 215, '1', '1', '1', '1'),
(85, 3, 215, '1', '1', '1', '1'),
(86, 15, 215, '1', '1', '1', '1'),
(87, 3, 211, '-1', '-1', '-1', '-1'),
(88, 15, 211, '-1', '-1', '-1', '-1'),
(89, 2, 216, '1', '1', '1', '1'),
(90, 3, 216, '1', '1', '1', '1'),
(91, 15, 216, '1', '1', '1', '1'),
(92, 3, 205, '1', '1', '1', '1'),
(93, 2, 218, '1', '1', '1', '1'),
(94, 15, 218, '1', '1', '1', '1'),
(95, 3, 218, '1', '1', '1', '1'),
(96, 2, 219, '1', '1', '1', '1'),
(97, 3, 219, '1', '1', '1', '1'),
(98, 15, 219, '1', '1', '1', '1'),
(99, 15, 204, '1', '1', '1', '1'),
(100, 15, 220, '1', '1', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `blocks`
--

CREATE TABLE IF NOT EXISTS `blocks` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `region_id` int(20) DEFAULT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `show_title` tinyint(1) NOT NULL DEFAULT '1',
  `class` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `weight` int(11) DEFAULT NULL,
  `element` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `visibility_roles` text COLLATE utf8_unicode_ci,
  `visibility_paths` text COLLATE utf8_unicode_ci,
  `visibility_php` text COLLATE utf8_unicode_ci,
  `params` text COLLATE utf8_unicode_ci,
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `block_alias` (`alias`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `blocks`
--

INSERT INTO `blocks` (`id`, `region_id`, `title`, `alias`, `body`, `show_title`, `class`, `status`, `weight`, `element`, `visibility_roles`, `visibility_paths`, `visibility_php`, `params`, `updated`, `created`) VALUES
(3, 4, 'About', 'about', 'This is the content of your block. Can be modified in admin panel.', 1, '', 1, 2, '', '', '', '', '', '2009-12-20 03:07:39', '2009-07-26 17:13:14'),
(5, 4, 'Meta', 'meta', '[menu:meta]', 1, '', 1, 6, '', '', '', '', '', '2009-12-22 05:17:39', '2009-09-12 06:36:22'),
(6, 4, 'Blogroll', 'blogroll', '[menu:blogroll]', 1, '', 1, 4, '', '', '', '', '', '2009-12-20 03:07:33', '2009-09-12 23:33:27'),
(7, 4, 'Categories', 'categories', '[vocabulary:categories type="blog"]', 1, '', 1, 3, '', '', '', '', '', '2009-12-20 03:07:36', '2009-10-03 16:52:50'),
(8, 4, 'Search', 'search', '', 0, '', 1, 1, 'Nodes.search', '', '', '', '', '2009-12-20 03:07:39', '2009-12-20 03:07:27'),
(9, 4, 'Recent Posts', 'recent_posts', '[node:recent_posts conditions="Node.type:blog" order="Node.id DESC" limit="5"]', 1, '', 1, 5, '', '', '', '', '', '2010-04-08 21:09:31', '2009-12-22 05:17:32');

-- --------------------------------------------------------

--
-- Table structure for table `cake_sessions`
--

CREATE TABLE IF NOT EXISTS `cake_sessions` (
  `id` varchar(255) NOT NULL,
  `data` text,
  `expires` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=64 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `lft`, `rght`, `name`, `status`) VALUES
(20, NULL, NULL, NULL, 'Algebra 1', 1),
(21, NULL, NULL, NULL, 'Geometry', 1),
(22, NULL, NULL, NULL, 'Algebra 2', 1),
(23, NULL, NULL, NULL, 'Photography', 1),
(24, NULL, NULL, NULL, 'Graphic Design', 1),
(25, NULL, NULL, NULL, 'Cooking', 1),
(26, NULL, NULL, NULL, 'Life Coaching', 1),
(27, NULL, NULL, NULL, 'Calculus', 1),
(28, NULL, NULL, NULL, 'Pre-Algebra', 1),
(29, NULL, NULL, NULL, 'Entrepreneurship ', 1),
(30, NULL, NULL, NULL, 'English', 1),
(31, NULL, NULL, NULL, 'Advanced English', 1),
(32, NULL, NULL, NULL, 'Basic English', 1),
(33, NULL, NULL, NULL, 'Basic Spanish', 1),
(34, NULL, NULL, NULL, 'Spanish', 1),
(35, NULL, NULL, NULL, 'Advanced Spanish', 1),
(36, NULL, NULL, NULL, 'HTML', 1),
(37, NULL, NULL, NULL, 'CSS', 1),
(38, NULL, NULL, NULL, 'PHP', 1),
(39, NULL, NULL, NULL, 'Java', 1),
(40, 31, NULL, NULL, 'Advanced English', 1),
(41, 35, NULL, NULL, 'Advanced Spanish', 1),
(42, 20, NULL, NULL, 'Algebra 1', 1),
(43, 22, NULL, NULL, 'Algebra 2', 1),
(44, 32, NULL, NULL, 'Basic English', 1),
(45, 33, NULL, NULL, 'Basic Spanish', 1),
(46, 27, NULL, NULL, 'Calculus', 1),
(47, 25, NULL, NULL, 'Cooking', 1),
(48, 37, NULL, NULL, 'CSS', 1),
(49, 30, NULL, NULL, 'English', 1),
(50, 29, NULL, NULL, 'Entrepreneurship ', 1),
(51, 21, NULL, NULL, 'Geometry', 1),
(52, 24, NULL, NULL, 'Graphic Design', 1),
(53, 36, NULL, NULL, 'HTML', 1),
(54, 39, NULL, NULL, 'Java', 1),
(55, 26, NULL, NULL, 'Life Coaching', 1),
(56, 23, NULL, NULL, 'Photography', 1),
(57, 38, NULL, NULL, 'PHP', 1),
(58, 28, NULL, NULL, 'Pre-Algebra', 1),
(59, 34, NULL, NULL, 'Spanish', 1),
(60, NULL, NULL, NULL, 'Chinese', 1),
(61, 60, NULL, NULL, 'Chinese', 1),
(62, NULL, NULL, NULL, 'College Admissions', 1),
(63, 62, NULL, NULL, 'College Admissions', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cometchat`
--

CREATE TABLE IF NOT EXISTS `cometchat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `from` int(10) unsigned NOT NULL,
  `to` int(10) unsigned NOT NULL,
  `message` text NOT NULL,
  `sent` int(10) unsigned NOT NULL DEFAULT '0',
  `read` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `direction` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `to` (`to`),
  KEY `from` (`from`),
  KEY `direction` (`direction`),
  KEY `read` (`read`),
  KEY `sent` (`sent`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=89 ;

--
-- Dumping data for table `cometchat`
--
-- --------------------------------------------------------

--
-- Table structure for table `cometchat_announcements`
--

CREATE TABLE IF NOT EXISTS `cometchat_announcements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `announcement` text NOT NULL,
  `time` int(10) unsigned NOT NULL,
  `to` int(10) NOT NULL,
  `recd` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `to` (`to`),
  KEY `time` (`time`),
  KEY `to_id` (`to`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cometchat_block`
--

CREATE TABLE IF NOT EXISTS `cometchat_block` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fromid` int(10) unsigned NOT NULL,
  `toid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fromid` (`fromid`),
  KEY `toid` (`toid`),
  KEY `fromid_toid` (`fromid`,`toid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cometchat_chatroommessages`
--

CREATE TABLE IF NOT EXISTS `cometchat_chatroommessages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL,
  `chatroomid` int(10) unsigned NOT NULL,
  `message` text NOT NULL,
  `sent` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `chatroomid` (`chatroomid`),
  KEY `sent` (`sent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cometchat_chatrooms`
--

CREATE TABLE IF NOT EXISTS `cometchat_chatrooms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `lastactivity` int(10) unsigned NOT NULL,
  `createdby` int(10) unsigned NOT NULL,
  `password` varchar(255) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `vidsession` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lastactivity` (`lastactivity`),
  KEY `createdby` (`createdby`),
  KEY `type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cometchat_chatrooms_users`
--

CREATE TABLE IF NOT EXISTS `cometchat_chatrooms_users` (
  `userid` int(10) unsigned NOT NULL,
  `chatroomid` int(10) unsigned NOT NULL,
  `lastactivity` int(10) unsigned NOT NULL,
  `isbanned` int(1) DEFAULT '0',
  PRIMARY KEY (`userid`,`chatroomid`) USING BTREE,
  KEY `chatroomid` (`chatroomid`),
  KEY `lastactivity` (`lastactivity`),
  KEY `userid` (`userid`),
  KEY `userid_chatroomid` (`chatroomid`,`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `cometchat_comethistory`
--

CREATE TABLE IF NOT EXISTS `cometchat_comethistory` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `sent` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `channel` (`channel`),
  KEY `sent` (`sent`),
  KEY `channel_sent` (`channel`,`sent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cometchat_games`
--

CREATE TABLE IF NOT EXISTS `cometchat_games` (
  `userid` int(10) unsigned NOT NULL,
  `score` int(10) unsigned DEFAULT NULL,
  `games` int(10) unsigned DEFAULT NULL,
  `recentlist` text,
  `highscorelist` text,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `cometchat_guests`
--

CREATE TABLE IF NOT EXISTS `cometchat_guests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lastactivity` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lastactivity` (`lastactivity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cometchat_status`
--

CREATE TABLE IF NOT EXISTS `cometchat_status` (
  `userid` int(10) unsigned NOT NULL,
  `message` text,
  `status` enum('available','away','busy','invisible','offline') DEFAULT NULL,
  `typingto` int(10) unsigned DEFAULT NULL,
  `typingtime` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`userid`),
  KEY `typingto` (`typingto`),
  KEY `typingtime` (`typingtime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cometchat_status`
--

INSERT INTO `cometchat_status` (`userid`, `message`, `status`, `typingto`, `typingtime`) VALUES
(1, NULL, 'available', NULL, NULL),
(4, NULL, 'available', NULL, NULL),
(8, NULL, 'available', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cometchat_videochatsessions`
--

CREATE TABLE IF NOT EXISTS `cometchat_videochatsessions` (
  `username` varchar(255) NOT NULL,
  `identity` varchar(255) NOT NULL,
  `timestamp` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`username`),
  KEY `username` (`username`),
  KEY `identity` (`identity`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `parent_id` int(20) DEFAULT NULL,
  `node_id` int(20) NOT NULL,
  `user_id` int(20) NOT NULL DEFAULT '0',
  `name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `rating` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `notify` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `comment_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'comment',
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `parent_id`, `node_id`, `user_id`, `name`, `email`, `website`, `ip`, `title`, `body`, `rating`, `status`, `notify`, `type`, `comment_type`, `lft`, `rght`, `updated`, `created`) VALUES
(1, NULL, 1, 0, 'Mr Croogo', 'email@example.com', 'http://www.croogo.org', '127.0.0.1', '', 'Hi, this is the first comment.', NULL, 1, 0, 'blog', 'comment', 1, 2, '2009-12-25 12:00:00', '2009-12-25 12:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE IF NOT EXISTS `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `position` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8_unicode_ci,
  `address2` text COLLATE utf8_unicode_ci,
  `state` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postcode` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `message_status` tinyint(1) NOT NULL DEFAULT '1',
  `message_archive` tinyint(1) NOT NULL DEFAULT '1',
  `message_count` int(11) NOT NULL DEFAULT '0',
  `message_spam_protection` tinyint(1) NOT NULL DEFAULT '0',
  `message_captcha` tinyint(1) NOT NULL DEFAULT '0',
  `message_notify` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `title`, `alias`, `body`, `name`, `position`, `address`, `address2`, `state`, `country`, `postcode`, `phone`, `fax`, `email`, `message_status`, `message_archive`, `message_count`, `message_spam_protection`, `message_captcha`, `message_notify`, `status`, `updated`, `created`) VALUES
(1, 'Contact', 'contact', '', '', '', '', '', '', '', '', '', '', 'you@your-site.com', 1, 0, 0, 0, 0, 1, 1, '2009-10-07 22:07:49', '2009-09-16 01:45:17');

-- --------------------------------------------------------

--
-- Table structure for table `invites`
--

CREATE TABLE IF NOT EXISTS `invites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invited_by` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `invited_date` datetime NOT NULL,
  `invited_link` varchar(255) NOT NULL,
  `linkused_or_not` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `invites`
--

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE IF NOT EXISTS `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `native` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `weight` int(11) DEFAULT NULL,
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `title`, `native`, `alias`, `status`, `weight`, `updated`, `created`) VALUES
(1, 'English', 'English', 'eng', 1, 1, '2009-11-02 21:37:38', '2009-11-02 20:52:00');

-- --------------------------------------------------------

--
-- Table structure for table `lessons`
--

CREATE TABLE IF NOT EXISTS `lessons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created` int(11) NOT NULL,
  `tutor` varchar(255) NOT NULL,
  `lesson_date` date NOT NULL,
  `lesson_time` time NOT NULL,
  `ampm` varchar(2) NOT NULL,
  `duration` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `repet` enum('signle','daily','weekly') NOT NULL,
  `notes` text NOT NULL,
  `add_date` datetime NOT NULL,
  `readlesson` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `readlessontutor` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `twiddlameetingid` int(11) NOT NULL,
  `is_confirmed` int(11) NOT NULL,
  `remainingduration` int(11) NOT NULL,
  `student_lessontaekn_time` int(11) NOT NULL,
  `laststatus_tutor` varchar(50) NOT NULL,
  `laststatus_student` varchar(50) NOT NULL,
  `opentok_session_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `student` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `lessons`
--

INSERT INTO `lessons` (`id`, `created`, `tutor`, `lesson_date`, `lesson_time`, `ampm`, `duration`, `subject`, `repet`, `notes`, `add_date`, `readlesson`, `status`, `readlessontutor`, `parent_id`, `twiddlameetingid`, `is_confirmed`, `remainingduration`, `student_lessontaekn_time`, `laststatus_tutor`, `laststatus_student`, `opentok_session_id`, `student`) VALUES
(1, 4, '8', '2014-03-15', '13:15:00', '', '2.5', 'b.com', '', 'sdafsadfasdf sdaf sadfasdf sdaf', '2014-03-15 00:00:00', 0, 0, 1, 1, 1540907, 1, 360, 960, '0', '0', NULL, NULL),
(2, 2, '4', '2014-03-17', '21:45:00', '', '0.5', 'Advanced English', '', '', '2014-03-16 00:00:00', 0, 0, 1, 2, 1543110, 1, 0, 0, '0', '0', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `lesson_payments`
--

CREATE TABLE IF NOT EXISTS `lesson_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `tutor_id` int(11) NOT NULL,
  `lesson_id` int(11) NOT NULL,
  `payment_amount` decimal(9,2) NOT NULL,
  `lesson_take` int(11) NOT NULL,
  `payment_date` datetime NOT NULL,
  `payment_complete` int(11) NOT NULL,
  `lesson_complete_tutor` int(11) NOT NULL,
  `lesson_complete_student` int(11) NOT NULL,
  `fee` decimal(9,2) NOT NULL,
  `stripe_charge_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lessonid` (`lesson_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `lesson_payments`
--

INSERT INTO `lesson_payments` (`id`, `student_id`, `tutor_id`, `lesson_id`, `payment_amount`, `lesson_take`, `payment_date`, `payment_complete`, `lesson_complete_tutor`, `lesson_complete_student`, `fee`, `stripe_charge_id`) VALUES
(1, 8, 4, 1, 54.00, 1, '0000-00-00 00:00:00', 0, 1, 1, 0.00, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `links`
--

CREATE TABLE IF NOT EXISTS `links` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `parent_id` int(20) DEFAULT NULL,
  `menu_id` int(20) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `target` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `visibility_roles` text COLLATE utf8_unicode_ci,
  `params` text COLLATE utf8_unicode_ci,
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

--
-- Dumping data for table `links`
--

INSERT INTO `links` (`id`, `parent_id`, `menu_id`, `title`, `class`, `description`, `link`, `target`, `rel`, `status`, `lft`, `rght`, `visibility_roles`, `params`, `updated`, `created`) VALUES
(5, NULL, 4, 'About', 'about', '', 'plugin:nodes/controller:nodes/action:view/type:page/slug:about', '', '', 1, 3, 4, '', '', '2009-10-06 23:14:21', '2009-08-19 12:23:33'),
(6, NULL, 4, 'Contact', 'contact', '', 'plugin:contacts/controller:contacts/action:view/contact', '', '', 1, 5, 6, '', '', '2009-10-06 23:14:45', '2009-08-19 12:34:56'),
(7, NULL, 3, 'Home', 'home', '', '/', '', '', 1, 5, 6, '', '', '2009-10-06 21:17:06', '2009-09-06 21:32:54'),
(8, NULL, 3, 'About', 'about', '', '/about', '', '', 1, 7, 10, '', '', '2009-09-12 03:45:53', '2009-09-06 21:34:57'),
(9, 8, 3, 'Child link', 'child-link', '', '#', '', '', 0, 8, 9, '', '', '2009-10-06 23:13:06', '2009-09-12 03:52:23'),
(10, NULL, 5, 'Site Admin', 'site-admin', '', '/admin', '', '', 1, 1, 2, '', '', '2009-09-12 06:34:09', '2009-09-12 06:34:09'),
(11, NULL, 5, 'Log out', 'log-out', '', '/plugin:users/controller:users/action:logout', '', '', 1, 7, 8, '["1","2"]', '', '2009-09-12 06:35:22', '2009-09-12 06:34:41'),
(12, NULL, 6, 'Croogo', 'croogo', '', 'http://www.croogo.org', '', '', 1, 3, 4, '', '', '2009-09-12 23:31:59', '2009-09-12 23:31:59'),
(14, NULL, 6, 'CakePHP', 'cakephp', '', 'http://www.cakephp.org', '', '', 1, 1, 2, '', '', '2009-10-07 03:25:25', '2009-09-12 23:38:43'),
(15, NULL, 3, 'Contact', 'contact', '', '/plugin:contacts/controller:contacts/action:view/contact', '', '', 1, 11, 12, '', '', '2009-09-16 07:54:13', '2009-09-16 07:53:33'),
(16, NULL, 5, 'Entries (RSS)', 'entries-rss', '', '/promoted.rss', '', '', 1, 3, 4, '', '', '2009-10-27 17:46:22', '2009-10-27 17:46:22'),
(17, NULL, 5, 'Comments (RSS)', 'comments-rss', '', '/comments.rss', '', '', 1, 5, 6, '', '', '2009-10-27 17:46:54', '2009-10-27 17:46:54');

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE IF NOT EXISTS `media` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `date` datetime NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `medias`
--

CREATE TABLE IF NOT EXISTS `medias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `date` datetime NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE IF NOT EXISTS `menus` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `weight` int(11) DEFAULT NULL,
  `link_count` int(11) NOT NULL,
  `params` text COLLATE utf8_unicode_ci,
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `menu_alias` (`alias`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `title`, `alias`, `class`, `description`, `status`, `weight`, `link_count`, `params`, `updated`, `created`) VALUES
(3, 'Main Menu', 'main', '', '', 1, NULL, 4, '', '2009-08-19 12:21:06', '2009-07-22 01:49:53'),
(4, 'Footer', 'footer', '', '', 1, NULL, 2, '', '2009-08-19 12:22:42', '2009-08-19 12:22:42'),
(5, 'Meta', 'meta', '', '', 1, NULL, 4, '', '2009-09-12 06:33:29', '2009-09-12 06:33:29'),
(6, 'Blogroll', 'blogroll', '', '', 1, NULL, 2, '', '2009-09-12 23:30:24', '2009-09-12 23:30:24');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contact_id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8_unicode_ci,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8_unicode_ci,
  `message_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `meta`
--

CREATE TABLE IF NOT EXISTS `meta` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `model` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Node',
  `foreign_key` int(20) DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci,
  `weight` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `meta`
--

INSERT INTO `meta` (`id`, `model`, `foreign_key`, `key`, `value`, `weight`) VALUES
(1, 'Node', 1, 'meta_keywords', 'key1, key2', NULL),
(2, 'Node', 2, '', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `my_statuses`
--

CREATE TABLE IF NOT EXISTS `my_statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by_id` int(11) NOT NULL,
  `status_text` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `date` datetime NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `details`, `date`, `image`, `status`) VALUES
(1, 'Five ways to score cheap textbooks', 'While college textbooks are still worth only a fraction of their weight in gold, there’s no debate that college textbooks are very pricey.  Doing the research to save money on textbooks can can make a substantial difference in the amount of money you can spend on other expenses like food (or fun). ', '2014-03-14 03:43:48', '', 1),
(2, 'Online geometry tutoring', 'Moving from algebra to geometry can stump even the most savvy math students. All of a sudden the Xs and numbers you’ve grown to love have become angles, proofs, and theorems. It can take time to wrap your mind around how to tackle a geometry concept. If you find yourself saying “huh?” more than “so that’s how you do that!” it may be a good time to work with an online geometry tutor.', '2014-03-14 03:40:26', '', 1),
(3, 'Access your past lessons at any time', 'To access materials from any of your lessons, just visit the Lessons page and click “View Lesson.” That will take you directly back to the lesson space where you can access all the content you’ve worked on in your session.', '2014-03-14 03:43:49', 'Penguins.jpg', 1),
(4, 'Set up regular lessons with your favorite tutor', 'When you’re taking a challenging course and you find a great tutor, it’s natural to want meet on a regular basis, whether it’s Thursday nights before your weekly problem sets are due or every Monday after lecture. Now, when you schedule lessons, it’s easy to set a weekly meeting time in just 2 clicks.', '2014-03-14 03:26:23', '024.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `nodes`
--

CREATE TABLE IF NOT EXISTS `nodes` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `parent_id` int(20) DEFAULT NULL,
  `user_id` int(20) NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `mime_type` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment_status` int(1) NOT NULL DEFAULT '1',
  `comment_count` int(11) DEFAULT '0',
  `promote` tinyint(1) NOT NULL DEFAULT '0',
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `terms` text COLLATE utf8_unicode_ci,
  `sticky` tinyint(1) NOT NULL DEFAULT '0',
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `visibility_roles` text COLLATE utf8_unicode_ci,
  `type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'node',
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `nodes`
--

INSERT INTO `nodes` (`id`, `parent_id`, `user_id`, `title`, `slug`, `body`, `excerpt`, `status`, `mime_type`, `comment_status`, `comment_count`, `promote`, `path`, `terms`, `sticky`, `lft`, `rght`, `visibility_roles`, `type`, `updated`, `created`) VALUES
(1, NULL, 1, 'Hello World', 'hello-world', '<p>Welcome to Croogo. This is your first post. You can edit or delete it from the admin panel.</p>', '', 1, '', 2, 1, 1, '/blog/hello-world', '{"1":"uncategorized"}', 0, 1, 2, '', 'blog', '2009-12-25 11:00:00', '2009-12-25 11:00:00'),
(2, NULL, 1, 'About', 'about', '<div class="span9">\r\n<h2 class="page-title">About Botangle</h2>\r\n\r\n<div class="StaticPageRight-Block">\r\n<div class="PageLeft-Block">\r\n<p class="FontStyle20">Who We Are?</p>\r\n\r\n<p>Botangle.com is an exciting new way to get involved with education that operates outside the status quo.&nbsp; It&rsquo;s an engaging platform that allows students and tutors access to a diverse array of resources that just do not exist in a normal classroom setting. &nbsp;</p>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<p class="FontStyle20">What We Do?</p>\r\n\r\n<p>At Botangle.com, we&rsquo;re building a community of learners and educators that are interested in accessing quality education and expanding their knowledge base outside the walls of the classroom. &nbsp;&nbsp;We can&rsquo;t build Botangle.com without you: &nbsp;won&rsquo;t you join us as we build the educational community of tomorrow, today? &nbsp;</p>\r\n</div>\r\n</div>\r\n</div>\r\n', '', 1, '', 0, 0, 0, '/about', '', 0, 1, 2, '', 'page', '2014-03-15 11:38:30', '2009-12-25 22:00:00'),
(3, NULL, 1, 'privacy', 'privacy', '<div class="span9">\r\n<h2 class="page-title">Privacy Policy</h2>\r\n\r\n<div class="StaticPageRight-Block">\r\n<div class="PageLeft-Block">\r\n<p class="FontStyle20">Who we are?</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n\r\n<p>Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui.</p>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<p class="FontStyle20">Who we are?</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n\r\n<p>Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui.</p>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<p class="FontStyle20">Who we are?</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n\r\n<p>Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui.</p>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<p class="FontStyle20">Who we are?</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n\r\n<p>Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui.</p>\r\n</div>\r\n</div>\r\n</div>\r\n', '', 1, NULL, 1, 0, 0, '/privacy', NULL, 0, 3, 4, '', 'page', '2014-01-02 13:15:43', '2013-12-26 19:27:57'),
(4, NULL, 1, 'FAQ', 'faq', '<div class="span9">\r\n<h2 class="page-title">Frequently Asked Questions</h2>\r\n\r\n<div class="StaticPageRight-Block">\r\n<div class="PageLeft-Block">\r\n<p class="FontStyle20"><strong><span style="line-height: 1.6em;">Q: How Can I Sign Up For Botangle?</span></strong></p>\r\n\r\n<p class="FontStyle20"><em>A: It&#39;s as 123. All you do is go to the <a href="http://botangle.com">front page</a> and register to be either a student or a tutor.</em></p>\r\n\r\n<p class="FontStyle20"><strong>Q: What&#39;s the difference between registering as a tutor or a student?&nbsp;</strong></p>\r\n\r\n<p class="FontStyle20"><em>A: If you choose to register as a tutor you&#39;ll be able to teach students from all around the world. If you choose to register as a student you get access to tutors locally around you or in Brazil.&nbsp;</em></p>\r\n\r\n<p class="FontStyle20"><strong>Q: Can I ask tutors questions like: Joe had 3 apples. He gave 2 to Sally. Calculate the diameter of the sun.</strong></p>\r\n\r\n<p class="FontStyle20"><em>A: Yes you can! Also the answer to your question is twice the radius.&nbsp;</em></p>\r\n\r\n<p class="FontStyle20"><strong>Q: bro are u srs</strong></p>\r\n\r\n<p class="FontStyle20"><em>A: yeah</em></p>\r\n\r\n<p class="FontStyle20"><strong>Q: What if I have other questions that aren&#39;t covered here?&nbsp;</strong></p>\r\n\r\n<p class="FontStyle20"><em>A: If you&#39;re having any problems with the website or just want to tell us we&#39;re doing a good job;&nbsp;feel free to tell us at contactus@botangle.com.</em></p>\r\n\r\n<p class="FontStyle20">&nbsp;</p>\r\n\r\n<p class="FontStyle16">&nbsp;</p>\r\n</div>\r\n</div>\r\n</div>\r\n', '', 1, NULL, 1, 0, 0, '/faq', NULL, 0, 5, 6, '', 'page', '2014-03-16 01:58:04', '2014-01-02 13:16:49'),
(5, NULL, 1, 'terms', 'terms', '<div class="span9">\r\n<h2 class="page-title">Terms &amp; Conditions</h2>\r\n\r\n<div class="StaticPageRight-Block">\r\n<div class="PageLeft-Block">\r\n<p class="FontStyle20">Botangle Terms of Use</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n\r\n<p>Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui.</p>\r\n&nbsp;\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n\r\n<p>Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui.</p>\r\n&nbsp;\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n\r\n<p>Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui.</p>\r\n&nbsp;\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n\r\n<p>Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui.</p>\r\n&nbsp;\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n\r\n<p>Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui.</p>\r\n&nbsp;\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n\r\n<p>Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui.</p>\r\n&nbsp;\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n\r\n<p>Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui.</p>\r\n&nbsp;\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n\r\n<p>Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui.</p>\r\n</div>\r\n</div>\r\n</div>\r\n', '', 1, NULL, 1, 0, 0, '/terms', NULL, 0, 7, 8, '', 'page', '2014-03-13 14:03:24', '2014-01-02 13:19:05'),
(6, NULL, 1, 'Contact Us', 'contact-us', '<div class="span9">\r\n<h2 class="page-title">Contact Us</h2>\r\n\r\n<div class="StaticPageRight-Block">\r\n<div class="PageLeft-Block">\r\n<p class="FontStyle20">We&#39;re here to help!</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n</div>\r\n\r\n<div class="row-fluid ">\r\n<div class="Get-in-Touch offset5">\r\n<p class="FontStyle20"><strong>Get in touch with us:</strong></p>\r\n</div>\r\n</div>\r\n\r\n<div class="row-fluid ">\r\n<div class="Social-Boxs Social-Email span3">\r\n<p class="FontStyle20"><a href="#">Email Us</a></p>\r\n</div>\r\n\r\n<div class="Social-Boxs Social-FB span3">\r\n<p class="FontStyle20"><a href="#">Facebook Us</a></p>\r\n</div>\r\n\r\n<div class="Social-Boxs Social-Tweet span3">\r\n<p class="FontStyle20"><a href="#">Follow Us</a></p>\r\n</div>\r\n\r\n<div class="Social-Boxs Social-Linkedin span3">\r\n<p class="FontStyle20"><a href="#">LinkedIn</a></p>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<p class="FontStyle20 offset5">Send us a Quick Message!</p>\r\n\r\n<form class="form-inline form-horizontal" role="form">\r\n<div class="row-fluid">\r\n<div class="form-group span6"><label class="sr-only" for="your_name">Your Name</label> <input class="form-control textbox1" id="your_name" placeholder="Your Name" type="text" /></div>\r\n\r\n<div class="form-group span6"><label class="sr-only" for="emial">Your Email Address</label> <input class="form-control textbox1" id="emial" placeholder="Your Email Address" type="email" /></div>\r\n</div>\r\n\r\n<div class="row-fluid marT10">\r\n<div class="span12 form-group"><label class="sr-only" for="category">Select Category</label> <input class="form-control textbox1" id="category" placeholder="Select Category" type="text" /></div>\r\n</div>\r\n\r\n<div class="row-fluid">\r\n<div class="span12 form-group marT10"><label class="sr-only" for="message">Your Message</label><textarea class="textarea" id="select-subject" placeholder="Your Message" rows="3"></textarea></div>\r\n</div>\r\n\r\n<div class="row-fluid marT10">\r\n<div class="span12 "><button class="btn btn-primary" type="submit">Submit</button></div>\r\n</div>\r\n</form>\r\n</div>\r\n</div>\r\n</div>\r\n', '', 1, NULL, 1, 0, 0, '/contact-us', NULL, 0, 9, 10, '', 'page', '2014-01-03 05:14:24', '0000-00-00 00:00:00'),
(7, NULL, 1, 'update', 'update', '<div class="span9">\r\n<h2 class="page-title">Updates</h2>\r\n\r\n<div class="StaticPageRight-Block">\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="media" src="images/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. <a href="#">Read More</a></p>\r\n&nbsp;\r\n\r\n<p>Posted on: feb 12, 2013</p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="media" src="images/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. <a href="#">Read More</a></p>\r\n&nbsp;\r\n\r\n<p>Posted on: feb 12, 2013</p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="media" src="images/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. <a href="#">Read More</a></p>\r\n&nbsp;\r\n\r\n<p>Posted on: feb 12, 2013</p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="media" src="images/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. <a href="#">Read More</a></p>\r\n&nbsp;\r\n\r\n<p>Posted on: feb 12, 2013</p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="media" src="images/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. <a href="#">Read More</a></p>\r\n&nbsp;\r\n\r\n<p>Posted on: feb 12, 2013</p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="media" src="images/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. <a href="#">Read More</a></p>\r\n&nbsp;\r\n\r\n<p>Posted on: feb 12, 2013</p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="media" src="images/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. <a href="#">Read More</a></p>\r\n&nbsp;\r\n\r\n<p>Posted on: feb 12, 2013</p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="media" src="images/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. <a href="#">Read More</a></p>\r\n&nbsp;\r\n\r\n<p>Posted on: feb 12, 2013</p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n', '', 1, NULL, 1, 0, 0, '/page/update', NULL, 0, 11, 12, '["3"]', 'page', '2014-02-18 07:22:38', '2014-01-03 05:25:33'),
(9, NULL, 0, 'media-1', 'media-1.jpg', '', '', 0, 'image/jpeg', 1, 0, 0, '/uploads/media-1.jpg', NULL, 0, 1, 2, NULL, 'attachment', '2014-03-13 13:50:29', '2014-02-18 07:16:27'),
(10, NULL, 1, 'Updates', 'updates', '<div class="span9">\r\n<h2 class="page-title">Updates</h2>\r\n\r\n<div class="StaticPageRight-Block">\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="" src="/demos/botangle/uploads/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n&nbsp;\r\n\r\n<p>link: <a href="#">www.duisauterure.com/id=345?newcat234</a></p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="" src="/demos/botangle/uploads/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n&nbsp;\r\n\r\n<p>link: <a href="#">www.duisauterure.com/id=345?newcat234</a></p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="" src="/demos/botangle/uploads/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n&nbsp;\r\n\r\n<p>link: <a href="#">www.duisauterure.com/id=345?newcat234</a></p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="" src="/demos/botangle/uploads/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n&nbsp;\r\n\r\n<p>link: <a href="#">www.duisauterure.com/id=345?newcat234</a></p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="" src="/demos/botangle/uploads/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n&nbsp;\r\n\r\n<p>link: <a href="#">www.duisauterure.com/id=345?newcat234</a></p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="" src="/demos/botangle/uploads/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n&nbsp;\r\n\r\n<p>link: <a href="#">www.duisauterure.com/id=345?newcat234</a></p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="" src="/demos/botangle/uploads/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n&nbsp;\r\n\r\n<p>link: <a href="#">www.duisauterure.com/id=345?newcat234</a></p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="" src="/demos/botangle/uploads/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n&nbsp;\r\n\r\n<p>link: <a href="#">www.duisauterure.com/id=345?newcat234</a></p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="" src="/demos/botangle/uploads/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n&nbsp;\r\n\r\n<p>link: <a href="#">www.duisauterure.com/id=345?newcat234</a></p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n', '', 1, NULL, 1, 0, 0, '/page/updates', NULL, 0, 15, 16, '', 'page', '2014-02-18 07:23:26', '2014-02-18 07:20:01'),
(11, NULL, 1, 'Media', 'media', '<div class="span9">\r\n<h2 class="page-title">Media</h2>\r\n\r\n<div class="StaticPageRight-Block">\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="" src="/demos/botangle/uploads/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n&nbsp;\r\n\r\n<p>link: <a href="#">www.duisauterure.com/id=345?newcat234</a></p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="" src="/demos/botangle/uploads/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n&nbsp;\r\n\r\n<p>link: <a href="#">www.duisauterure.com/id=345?newcat234</a></p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="" src="/demos/botangle/uploads/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n&nbsp;\r\n\r\n<p>link: <a href="#">www.duisauterure.com/id=345?newcat234</a></p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="" src="/demos/botangle/uploads/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n&nbsp;\r\n\r\n<p>link: <a href="#">www.duisauterure.com/id=345?newcat234</a></p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="" src="/demos/botangle/uploads/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n&nbsp;\r\n\r\n<p>link: <a href="#">www.duisauterure.com/id=345?newcat234</a></p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="" src="/demos/botangle/uploads/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n&nbsp;\r\n\r\n<p>link: <a href="#">www.duisauterure.com/id=345?newcat234</a></p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="" src="/demos/botangle/uploads/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n&nbsp;\r\n\r\n<p>link: <a href="#">www.duisauterure.com/id=345?newcat234</a></p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="" src="/demos/botangle/uploads/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n&nbsp;\r\n\r\n<p>link: <a href="#">www.duisauterure.com/id=345?newcat234</a></p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="PageLeft-Block">\r\n<div class="row-fluid">\r\n<div class="span3 media-img"><a href="#"><img alt="" src="/demos/botangle/uploads/media-1.jpg" /></a></div>\r\n\r\n<div class="span9 media-text">\r\n<p class="FontStyle20"><a href="#">Top 100 stidents of the year</a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>\r\n&nbsp;\r\n\r\n<p>link: <a href="#">www.duisauterure.com/id=345?newcat234</a></p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n', '', 1, NULL, 1, 0, 0, '/page/media', NULL, 0, 17, 18, '', 'page', '2014-02-18 07:23:15', '2014-02-18 07:20:32');

-- --------------------------------------------------------

--
-- Table structure for table `nodes_taxonomies`
--

CREATE TABLE IF NOT EXISTS `nodes_taxonomies` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `node_id` int(20) NOT NULL DEFAULT '0',
  `taxonomy_id` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `nodes_taxonomies`
--

INSERT INTO `nodes_taxonomies` (`id`, `node_id`, `taxonomy_id`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `regions`
--

CREATE TABLE IF NOT EXISTS `regions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `block_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `region_alias` (`alias`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

--
-- Dumping data for table `regions`
--

INSERT INTO `regions` (`id`, `title`, `alias`, `description`, `block_count`) VALUES
(3, 'none', 'none', '', 0),
(4, 'right', 'right', '', 6),
(6, 'left', 'left', '', 0),
(7, 'header', 'header', '', 0),
(8, 'footer', 'footer', '', 0),
(9, 'region1', 'region1', '', 0),
(10, 'region2', 'region2', '', 0),
(11, 'region3', 'region3', '', 0),
(12, 'region4', 'region4', '', 0),
(13, 'region5', 'region5', '', 0),
(14, 'region6', 'region6', '', 0),
(15, 'region7', 'region7', '', 0),
(16, 'region8', 'region8', '', 0),
(17, 'region9', 'region9', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE IF NOT EXISTS `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rating` int(11) NOT NULL,
  `reviews` text NOT NULL,
  `lesson_id` int(11) NOT NULL,
  `rate_by` int(11) NOT NULL,
  `rate_to` int(11) NOT NULL,
  `add_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `rating`, `reviews`, `lesson_id`, `rate_by`, `rate_to`, `add_date`) VALUES
(2, 5, 'nice', 10, 8, 4, '2014-03-14 09:04:18'),
(3, 3, 'its ok .....', 14, 8, 4, '2014-03-14 09:05:06');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_alias` (`alias`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `title`, `alias`, `created`, `updated`) VALUES
(1, 'Admin', 'admin', '2009-04-05 00:10:34', '2009-04-05 00:10:34'),
(2, 'Tutor', 'tutor', '2009-04-05 00:10:50', '2009-04-06 05:20:38'),
(4, 'Student', 'student', '2009-04-05 00:12:38', '2009-04-07 01:41:45');

-- --------------------------------------------------------

--
-- Table structure for table `roles_users`
--

CREATE TABLE IF NOT EXISTS `roles_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `granted_by` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pk_role_users` (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------


--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `key` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `input_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `editable` tinyint(1) NOT NULL DEFAULT '1',
  `weight` int(11) DEFAULT NULL,
  `params` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=40 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `key`, `value`, `title`, `description`, `input_type`, `editable`, `weight`, `params`) VALUES
(6, 'Site.title', 'Botangle', '', '', '', 1, 1, ''),
(7, 'Site.tagline', '', '', '', 'textarea', 1, 2, ''),
(8, 'Site.email', 'contactus@botangle.com', '', '', '', 1, 3, ''),
(9, 'Site.status', '1', '', '', 'checkbox', 1, 6, ''),
(12, 'Meta.robots', 'index, follow', '', '', '', 1, 6, ''),
(13, 'Meta.keywords', 'croogo, Croogo', '', '', 'textarea', 1, 7, ''),
(14, 'Meta.description', 'Croogo - A CakePHP powered Content Management System', '', '', 'textarea', 1, 8, ''),
(15, 'Meta.generator', 'Croogo - Content Management System', '', '', '', 0, 9, ''),
(16, 'Service.akismet_key', 'your-key', '', '', '', 1, 11, ''),
(17, 'Service.recaptcha_public_key', 'your-public-key', '', '', '', 1, 12, ''),
(18, 'Service.recaptcha_private_key', 'your-private-key', '', '', '', 1, 13, ''),
(19, 'Service.akismet_url', 'http://your-blog.com', '', '', '', 1, 10, ''),
(20, 'Site.theme', '', '', '', '', 0, 14, ''),
(21, 'Site.feed_url', '', '', '', '', 0, 15, ''),
(22, 'Reading.nodes_per_page', '5', '', '', '', 1, 16, ''),
(23, 'Writing.wysiwyg', '1', 'Enable WYSIWYG editor', '', 'checkbox', 1, 17, ''),
(24, 'Comment.level', '1', '', 'levels deep (threaded comments)', '', 1, 18, ''),
(25, 'Comment.feed_limit', '10', '', 'number of comments to show in feed', '', 1, 19, ''),
(26, 'Site.locale', 'eng', '', '', 'text', 0, 20, ''),
(27, 'Reading.date_time_format', 'D, M d Y H:i:s', '', '', '', 1, 21, ''),
(28, 'Comment.date_time_format', 'M d, Y', '', '', '', 1, 22, ''),
(29, 'Site.timezone', '0', '', 'zero (0) for GMT', '', 1, 4, ''),
(32, 'Hook.bootstraps', 'Settings,Comments,Contacts,Nodes,Meta,Menus,Users,Blocks,Taxonomy,FileManager,Wysiwyg,Ckeditor,Categories,Messages,News,Media', '', '', '', 0, 23, ''),
(33, 'Comment.email_notification', '1', 'Enable email notification', '', 'checkbox', 1, 24, ''),
(34, 'Access Control.multiRole', '0', 'Enable Multiple Roles', '', 'checkbox', 1, 25, ''),
(35, 'Access Control.rowLevel', '0', 'Row Level Access Control', '', 'checkbox', 1, 26, ''),
(36, 'Access Control.autoLoginDuration', '+1 week', '"Remember Me" Duration', 'Eg: +1 day, +1 week. Leave empty to disable.', 'text', 1, 27, ''),
(37, 'Access Control.models', '', 'Models with Row Level Acl', 'Select models to activate Row Level Access Control on', 'multiple', 1, 26, 'multiple=checkbox\noptions={"Nodes.Node": "Node", "Blocks.Block": "Block", "Menus.Menu": "Menu", "Menus.Link": "Link"}'),
(38, 'Croogo.installed', '1', '', '', '', 0, 28, ''),
(39, 'Croogo.version', '1.5.5', '', '', '', 0, 29, '');

-- --------------------------------------------------------

--
-- Table structure for table `taxonomies`
--

CREATE TABLE IF NOT EXISTS `taxonomies` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `parent_id` int(20) DEFAULT NULL,
  `term_id` int(10) NOT NULL,
  `vocabulary_id` int(10) NOT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `taxonomies`
--

INSERT INTO `taxonomies` (`id`, `parent_id`, `term_id`, `vocabulary_id`, `lft`, `rght`) VALUES
(1, NULL, 1, 1, 1, 2),
(2, NULL, 2, 1, 3, 4),
(3, NULL, 3, 2, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `terms`
--

CREATE TABLE IF NOT EXISTS `terms` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `terms`
--

INSERT INTO `terms` (`id`, `title`, `slug`, `description`, `updated`, `created`) VALUES
(1, 'Uncategorized', 'uncategorized', '', '2009-07-22 03:38:43', '2009-07-22 03:34:56'),
(2, 'Announcements', 'announcements', '', '2010-05-16 23:57:06', '2009-07-22 03:45:37'),
(3, 'mytag', 'mytag', '', '2009-08-26 14:42:43', '2009-08-26 14:42:43');

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE IF NOT EXISTS `testimonials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `date` datetime NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `types`
--

CREATE TABLE IF NOT EXISTS `types` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `format_show_author` tinyint(1) NOT NULL DEFAULT '1',
  `format_show_date` tinyint(1) NOT NULL DEFAULT '1',
  `comment_status` int(1) NOT NULL DEFAULT '1',
  `comment_approve` tinyint(1) NOT NULL DEFAULT '1',
  `comment_spam_protection` tinyint(1) NOT NULL DEFAULT '0',
  `comment_captcha` tinyint(1) NOT NULL DEFAULT '0',
  `params` text COLLATE utf8_unicode_ci,
  `plugin` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type_alias` (`alias`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `types`
--

INSERT INTO `types` (`id`, `title`, `alias`, `description`, `format_show_author`, `format_show_date`, `comment_status`, `comment_approve`, `comment_spam_protection`, `comment_captcha`, `params`, `plugin`, `updated`, `created`) VALUES
(1, 'Page', 'page', 'A page is a simple method for creating and displaying information that rarely changes, such as an "About us" section of a website. By default, a page entry does not allow visitor comments.', 0, 0, 0, 1, 0, 0, '', '', '2009-09-09 00:23:24', '2009-09-02 18:06:27'),
(2, 'Blog', 'blog', 'A blog entry is a single post to an online journal, or blog.', 1, 1, 2, 1, 0, 0, '', '', '2009-09-15 12:15:43', '2009-09-02 18:20:44'),
(4, 'Node', 'node', 'Default content type.', 1, 1, 2, 1, 0, 0, '', '', '2009-10-06 21:53:15', '2009-09-05 23:51:56');

-- --------------------------------------------------------

--
-- Table structure for table `types_vocabularies`
--

CREATE TABLE IF NOT EXISTS `types_vocabularies` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type_id` int(10) NOT NULL,
  `vocabulary_id` int(10) NOT NULL,
  `weight` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=33 ;

--
-- Dumping data for table `types_vocabularies`
--

INSERT INTO `types_vocabularies` (`id`, `type_id`, `vocabulary_id`, `weight`) VALUES
(24, 4, 1, NULL),
(25, 4, 2, NULL),
(30, 2, 1, NULL),
(31, 2, 2, NULL),
(32, 1, 3, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `usermessages`
--

CREATE TABLE IF NOT EXISTS `usermessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `send_to` int(11) NOT NULL,
  `sent_from` int(11) NOT NULL,
  `body` text NOT NULL,
  `attached_files` varchar(255) NOT NULL,
  `readmessage` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=66 ;

--
-- Dumping data for table `usermessages`
--

-- --------------------------------------------------------

--
-- Table structure for table `userpoints`
--

CREATE TABLE IF NOT EXISTS `userpoints` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `point` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `trophyamountlesson` varchar(20) NOT NULL,
  `paid_or_not` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `username` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `lname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `website` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activation_key` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8_unicode_ci,
  `timezone` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `qualification` text COLLATE utf8_unicode_ci NOT NULL,
  `teaching_experience` text COLLATE utf8_unicode_ci NOT NULL,
  `extracurricular_interests` text COLLATE utf8_unicode_ci NOT NULL,
  `university` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `other_experience` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `expertise` text COLLATE utf8_unicode_ci NOT NULL,
  `aboutme` text COLLATE utf8_unicode_ci NOT NULL,
  `profilepic` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  `is_online` tinyint(1) NOT NULL,
  `lastactivity` int(11) DEFAULT '0',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `stripe_user_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `access_token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `stripe_publishable_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `claim_status` int(11) NOT NULL,
  `refresh_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stripe_customer_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link_fb` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link_twitter` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link_googleplus` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link_thumblr` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `users`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_logs`
--

CREATE TABLE IF NOT EXISTS `user_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_log_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_rates`
--

CREATE TABLE IF NOT EXISTS `user_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `price_type` varchar(10) NOT NULL,
  `rate` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user_rates`
--

INSERT INTO `user_rates` (`id`, `userid`, `price_type`, `rate`) VALUES
(1, 4, 'permin', 201),
(2, 20, 'permin', 12),
(3, 25, 'perhour', 10);

-- --------------------------------------------------------

--
-- Table structure for table `vocabularies`
--

CREATE TABLE IF NOT EXISTS `vocabularies` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `multiple` tinyint(1) NOT NULL DEFAULT '0',
  `tags` tinyint(1) NOT NULL DEFAULT '0',
  `plugin` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `weight` int(11) DEFAULT NULL,
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vocabulary_alias` (`alias`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `vocabularies`
--

INSERT INTO `vocabularies` (`id`, `title`, `alias`, `description`, `required`, `multiple`, `tags`, `plugin`, `weight`, `updated`, `created`) VALUES
(1, 'Categories', 'categories', '', 0, 1, 0, '', 1, '2010-05-17 20:03:11', '2009-07-22 02:16:21'),
(2, 'Tags', 'tags', '', 0, 1, 0, '', 2, '2010-05-17 20:03:11', '2009-07-22 02:16:34'),
(3, 'Faq', 'faq', 'faq', 0, 0, 0, NULL, NULL, '2013-12-23 19:23:48', '2013-12-23 19:23:48');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
